package com.hugo.wadownloader

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.Toast

class DownloaderService : AccessibilityService() {

    companion object {
        private val WA_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")

        // Coincide con "Descargar", "Download", etc., pero no con "Descargando"/"Downloading"
        private val DOWNLOAD_REGEX = Regex(
            "^(descargar|download|baixar|t[eé]l[eé]charger)(?!\\p{L})",
            RegexOption.IGNORE_CASE
        )
    }

    private val ui = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var button: Button? = null

    @Volatile
    private var running = false
    private var worker: Thread? = null

    // ---------- Ciclo de vida ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        running = false
    }

    override fun onDestroy() {
        running = false
        removeOverlay()
        super.onDestroy()
    }

    // ---------- Boton flotante ----------

    private fun addOverlay() {
        val b = Button(this)
        b.text = "▶ Iniciar"
        b.textSize = 12f
        b.alpha = 0.9f
        b.setOnClickListener { if (running) running = false else startRun() }
        b.setOnLongClickListener {
            dumpTree()
            true
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = 16
        lp.y = 300

        windowManager?.addView(b, lp)
        button = b
    }

    private fun removeOverlay() {
        try {
            button?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        button = null
    }

    private fun setStatus(text: String) {
        ui.post { button?.text = text }
    }

    private fun toast(text: String) {
        ui.post { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    }

    // ---------- Ejecucion ----------

    private fun startRun() {
        if (running) return
        running = true
        setStatus("■ Parar (0)")
        val t = Thread {
            var total = 0
            try {
                total = runLoop()
            } catch (e: Exception) {
                toast("Error: ${e.message}")
            } finally {
                running = false
                setStatus("▶ Iniciar")
            }
            toast("Listo: $total descargas iniciadas")
        }
        worker = t
        t.start()
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
            running = false
        }
    }

    private fun runLoop(): Int {
        var total = 0
        var stuck = 0

        while (running) {
            val root = rootInActiveWindow
            val pkg = root?.packageName?.toString()
            if (root == null || pkg == null || pkg !in WA_PACKAGES) {
                setStatus("■ Abre el chat")
                pause(1500)
                continue
            }

            val list = findScrollable(root)
            val area = list ?: root

            // 1) Tocar los botones de descarga visibles
            val targets = findDownloadTargets(area)
            for (target in targets) {
                if (!running) break
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    total++
                    setStatus("■ Parar ($total)")
                    pause((600..1200).random().toLong())
                }
            }
            if (!running) break

            // 2) Subir en el chat
            if (list == null) {
                stuck++
                pause(1500)
            } else {
                val before = signature(list)
                val moved = scrollUp(list)
                pause(if (stuck > 0) 2500L else 1200L)
                val newRoot = rootInActiveWindow
                val newList = if (newRoot != null) findScrollable(newRoot) else null
                val after = if (newList != null) signature(newList) else 0
                if (!moved || after == before) stuck++ else stuck = 0
            }

            if (stuck >= 3) break
        }
        return total
    }

    // ---------- Busqueda de nodos ----------

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val r = Rect()
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.isScrollable) {
                n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) {
                    best = n
                    bestArea = area
                }
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { queue.add(it) }
            }
        }
        return best
    }

    private fun isDownloadNode(n: AccessibilityNodeInfo): Boolean {
        val d = n.contentDescription?.toString()?.trim()
        val t = n.text?.toString()?.trim()
        return (d != null && DOWNLOAD_REGEX.containsMatchIn(d)) ||
            (t != null && DOWNLOAD_REGEX.containsMatchIn(t))
    }

    private fun clickableTarget(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.isClickable && n.isEnabled) return n
            n = n.parent
            depth++
        }
        return null
    }

    private fun findDownloadTargets(root: AccessibilityNodeInfo): Collection<AccessibilityNodeInfo> {
        val out = LinkedHashMap<String, AccessibilityNodeInfo>()
        val r = Rect()

        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 40) return
            if (n.isVisibleToUser && isDownloadNode(n)) {
                val target = clickableTarget(n)
                if (target != null) {
                    target.getBoundsInScreen(r)
                    out[r.flattenToString()] = target
                }
                return
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { walk(it, depth + 1) }
            }
        }

        walk(root, 0)
        return out.values
    }

    private fun scrollUp(list: AccessibilityNodeInfo): Boolean {
        return list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ||
            list.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id)
    }

    private fun signature(root: AccessibilityNodeInfo): Int {
        val sb = StringBuilder()
        collect(root, sb, 0)
        return sb.toString().hashCode()
    }

    private fun collect(n: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 25 || sb.length > 20000) return
        n.text?.let { sb.append(it).append('|') }
        n.contentDescription?.let { sb.append(it).append('|') }
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { collect(it, sb, depth + 1) }
        }
    }

    // ---------- Diagnostico (mantener presionado el boton) ----------

    private fun dumpTree() {
        Thread {
            val root = rootInActiveWindow
            val sb = StringBuilder()
            if (root == null) {
                sb.append("Sin ventana activa")
            } else {
                dumpNode(root, 0, sb)
            }
            val text = sb.toString().take(40000)
            ui.post {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("dump", text))
                Toast.makeText(this, "Copiado: ${text.length} caracteres", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun dumpNode(n: AccessibilityNodeInfo, depth: Int, sb: StringBuilder) {
        if (depth > 40 || sb.length > 40000) return
        val id = n.viewIdResourceName
        val txt = n.text?.toString()
        val desc = n.contentDescription?.toString()
        if (id != null || !txt.isNullOrEmpty() || !desc.isNullOrEmpty() || n.isClickable || n.isScrollable) {
            sb.append(" ".repeat(minOf(depth, 12)))
            sb.append(n.className?.toString()?.substringAfterLast('.'))
            if (id != null) sb.append(" id=").append(id.substringAfter(":id/"))
            if (!txt.isNullOrEmpty()) sb.append(" t=\"").append(txt.take(40)).append('"')
            if (!desc.isNullOrEmpty()) sb.append(" d=\"").append(desc.take(40)).append('"')
            if (n.isClickable) sb.append(" [click]")
            if (n.isScrollable) sb.append(" [scroll]")
            sb.append('\n')
        }
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { dumpNode(it, depth + 1, sb) }
        }
    }
}
