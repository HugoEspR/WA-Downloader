package com.hugo.wadownloader

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.TextView

class ShareReceiverActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        status = TextView(this)
        status.textSize = 16f
        status.setPadding(pad, pad, pad, pad)
        status.text = "Preparando..."
        setContentView(status)
        setFinishOnTouchOutside(false)

        val uris = extractUris(intent)
        if (uris.isEmpty()) {
            status.text = "No recibi archivos"
            ui.postDelayed({ finish() }, 1500)
            return
        }

        Thread {
            var ok = 0
            var fail = 0
            for ((i, u) in uris.withIndex()) {
                ui.post { status.text = "Guardando ${i + 1} de ${uris.size}..." }
                if (saveOne(u)) ok++ else fail++
            }
            ui.post {
                status.text = if (fail == 0) {
                    "Listo: $ok guardadas en la galeria (carpeta WA Guardar)"
                } else {
                    "Listo: $ok guardadas, $fail fallaron"
                }
                ui.postDelayed({ finish() }, 2000)
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun extractUris(i: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        if (i.action == Intent.ACTION_SEND) {
            val u: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            if (u != null) out.add(u)
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            val list: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            if (list != null) out.addAll(list)
        }
        val clip = i.clipData
        if (out.isEmpty() && clip != null) {
            for (k in 0 until clip.itemCount) {
                val u = clip.getItemAt(k).uri
                if (u != null) out.add(u)
            }
        }
        return out.toList()
    }

    private fun displayName(src: Uri): String? {
        return try {
            contentResolver.query(src, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun saveOne(src: Uri): Boolean {
        var dst: Uri? = null
        try {
            var mime = contentResolver.getType(src) ?: "image/jpeg"
            if (!mime.startsWith("image/") && !mime.startsWith("video/")) mime = "image/jpeg"
            val isVideo = mime.startsWith("video/")

            var name = displayName(src) ?: "WA_${System.currentTimeMillis()}"
            if (!name.contains('.')) {
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
                if (ext != null) name = "$name.$ext"
            }

            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            val base = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/WA Guardar")
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)

            val collection = if (isVideo) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }

            val target = contentResolver.insert(collection, values) ?: return false
            dst = target

            val input = contentResolver.openInputStream(src) ?: throw IllegalStateException("sin entrada")
            val output = contentResolver.openOutputStream(target) ?: throw IllegalStateException("sin salida")
            input.use { i ->
                output.use { o ->
                    i.copyTo(o)
                }
            }

            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(target, done, null, null)
            return true
        } catch (_: Exception) {
            val d = dst
            if (d != null) {
                try {
                    contentResolver.delete(d, null, null)
                } catch (_: Exception) {
                }
            }
            return false
        }
    }
}
