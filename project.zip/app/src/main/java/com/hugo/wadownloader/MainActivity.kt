package com.hugo.wadownloader

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val info = TextView(this)
        info.text = getString(R.string.instrucciones)
        info.textSize = 16f
        info.setPadding(pad, pad, pad, pad)

        val scroll = ScrollView(this)
        scroll.addView(info)
        setContentView(scroll)
    }
}
